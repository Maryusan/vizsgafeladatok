function Rng(alsoHatar: number, felsoHatar: number) : number{
    return Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar;
}

function TombGenerator(meret:number, alsoHatar:number, felsoHatar:number):number[]
{
    var tomb:number[]=[];
    var i:number=0;
    var index:number=0;
    for(i=0;i<meret;i++)
    {
        tomb[index]=Rng(alsoHatar, felsoHatar);
        index++;
    }
    return tomb;
}
function Duplazo(VizsgaltTomb:number[]):number[]
{
    var tomb:number[]=[];
    var i:number=0;
    var index:number=0;
    for(i=0;i<VizsgaltTomb.length;i++)
    {
        tomb[index]=2*VizsgaltTomb[i];
        index++;               
    }
    return tomb;
}
function primSzam(szam) {
    for (let i = 2; i < szam; i++) {
        if (szam % i == 0) {
            return false;
        }
    }
    return true;
}
function PrimekSzama(VizsgaltTomb:number[]):number
{
    var db:number=0;
    for(let i=0;i<VizsgaltTomb.length;i++)
    {
        let szam:number = VizsgaltTomb[i];
        if (primSzam(szam))
        {
            db++;               
        }
    }
    return db;

}

function EgyediElem(VizsgaltTomb:number[]):number[]
{
    var db:number=0;
    var utolso:number=-10000;
    var tomb:number[]=[];
    var index:number=0;    
    for(let i=0;i<VizsgaltTomb.length;i++)
    {
        let szam:number = VizsgaltTomb[i];
        if (szam!=utolso)
        {
            tomb[index]=szam;
            index++;
        }       
            utolso = szam;        
    }
    return tomb;

}




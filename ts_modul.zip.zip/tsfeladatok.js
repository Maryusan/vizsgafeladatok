function Rng(alsoHatar, felsoHatar) {
    return Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar;
}
function TombGenerator(meret, alsoHatar, felsoHatar) {
    var tomb = [];
    var i = 0;
    var index = 0;
    for (i = 0; i < meret; i++) {
        tomb[index] = Rng(alsoHatar, felsoHatar);
        index++;
    }
    return tomb;
}
function Duplazo(VizsgaltTomb) {
    var tomb = [];
    var i = 0;
    var index = 0;
    for (i = 0; i < VizsgaltTomb.length; i++) {
        tomb[index] = 2 * VizsgaltTomb[i];
        index++;
    }
    return tomb;
}
function primSzam(szam) {
    for (var i = 2; i < szam; i++) {
        if (szam % i == 0) {
            return false;
        }
    }
    return true;
}
function PrimekSzama(VizsgaltTomb) {
    var db = 0;
    for (var i = 0; i < VizsgaltTomb.length; i++) {
        var szam = VizsgaltTomb[i];
        if (primSzam(szam)) {
            db++;
        }
    }
    return db;
}
function EgyediElem(VizsgaltTomb) {
    var db = 0;
    var utolso = -10000;
    var tomb = [];
    var index = 0;
    for (var i = 0; i < VizsgaltTomb.length; i++) {
        var szam = VizsgaltTomb[i];
        if (szam != utolso) {
            tomb[index] = szam;
            index++;
        }
        utolso = szam;
    }
    return tomb;
}
